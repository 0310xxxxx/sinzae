import React, {useEffect, useState} from 'react';

const Dashboard = () => {
    const [userId, setUserId] = useState('');

    useEffect(() => {
        const fetchUserId = async () => {
            try{
                const response = await fetch('http://localhost:8080/api/dashboard', {
                    method: "GET",
                    credentials: 'include'
                });
                if (response.ok){
                    const userId = await response.text();
                    console.log(response);
                    setUserId(userId);
                } else {
                    console.log("ㅋㅋㅋㅋㅋ 병신인가");
                    console.log(response);
                }
            } catch (error){
                console.error('에러내용임', error);
            }
        };

        fetchUserId();
    }, []);

    return (
        <div>
            <h1>Dashboard</h1>
            {userId ? (
                <p>{userId}님 안녕하세요!</p>
            ) : (
                <p>Loading...</p>
            )}
        </div>
    );
};

export default Dashboard;
