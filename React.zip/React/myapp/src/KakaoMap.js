/* global kakao */
import React, { useState, useEffect } from 'react';
import "./KakaoMap.css";

const KakaoMap = () => {
    const [keyword, setKeyword] = useState(''); // 검색어 상태 관리
    const [places, setPlaces] = useState([]); // 검색 결과 장소 목록 상태 관리
    const [map, setMap] = useState(null); // 지도 객체 상태 관리
    const [kakaoLoaded, setKakaoLoaded] = useState(false); // Kakao API 로드 상태 관리
    const markers = []; // 마커를 담을 배열

    // 검색어 입력 시 상태 업데이트
    const handleChange = (e) => {
        setKeyword(e.target.value);
    };

    // 키워드로 장소를 검색하는 함수
    const searchPlaces = (e) => {
        e.preventDefault();
        if (!keyword.trim()) {
            alert('검색어를 입력해주세요!');
            return;
        }

        if (!kakaoLoaded) {
            alert('Kakao Maps API is not loaded yet.');
            return;
        }

        const ps = new kakao.maps.services.Places();

        // 장소 검색 요청
        ps.keywordSearch(keyword, placesSearchCB);
    };

    // 검색 결과 콜백 함수
    const placesSearchCB = (data, status, pagination) => {
        if (status === kakao.maps.services.Status.OK) {
            setPlaces(data); // 검색 결과 업데이트
            displayPlaces(data); // 검색 결과 지도에 표시
            displayPagination(pagination); // 페이지 번호 표시
        } else if (status === kakao.maps.services.Status.ZERO_RESULT) {
            alert('검색 결과가 존재하지 않습니다.');
        } else if (status === kakao.maps.services.Status.ERROR) {
            alert('검색 결과 중 오류가 발생했습니다.');
        }
    };

    // 검색 결과 지도에 표시하는 함수
    const displayPlaces = (places) => {
        const bounds = new kakao.maps.LatLngBounds();

        // 이전에 생성된 마커 제거
        removeMarker();

        places.forEach((place, index) => {
            const placePosition = new kakao.maps.LatLng(place.y, place.x);
            const marker = addMarker(placePosition, place.place_name);
            bounds.extend(placePosition); // 검색된 장소 위치를 기준으로 지도 범위를 재설정하기 위해 bounds 설정
            markers.push(marker);
        });

        // 검색된 장소 위치를 기준으로 지도 범위를 재설정합니다.
        map.setBounds(bounds);
    };

    // 마커를 생성하고 지도 위에 마커를 표시하는 함수
    const addMarker = (position, title) => {
        const infowindow = new kakao.maps.InfoWindow({ zIndex: 1 });
        const marker = new kakao.maps.Marker({ position });

        marker.setMap(map); // 지도 위에 마커를 표시합니다.

        kakao.maps.event.addListener(marker, 'mouseover', () => {
            displayInfowindow(marker, title, infowindow);
        });

        kakao.maps.event.addListener(marker, 'mouseout', () => {
            infowindow.close();
        });

        return marker;
    };

    // 마커를 모두 제거하는 함수
    const removeMarker = () => {
        markers.forEach((marker) => {
            marker.setMap(null);
        });
        markers.length = 0;
    };

    // 인포윈도우에 장소명을 표시하는 함수
    const displayInfowindow = (marker, title, infowindow) => {
        const content = `<div style="padding:5px;z-index:1;">${title}</div>`;
        infowindow.setContent(content);
        infowindow.open(map, marker);
    };

    // 검색 결과 목록 하단에 페이지번호를 표시하는 함수
    const displayPagination = (pagination) => {
        const paginationEl = document.getElementById('pagination');
        paginationEl.innerHTML = ''; // 기존에 있던 요소들을 모두 지웁니다.

        const container = document.createElement('div');
        container.classList.add('pagination-container');

        for (let i = 1; i <= pagination.last; i++) {
            const el = document.createElement('button');
            el.type = 'button';
            el.innerHTML = i;
            if (i === pagination.current) {
                el.classList.add('active');
            } else {
                el.addEventListener('click', () => {
                    pagination.gotoPage(i);
                });
            }
            container.appendChild(el);
        }

        paginationEl.appendChild(container);
    };

    // 지도 타입을 변경하는 함수
    const setMapType = (maptype) => {
        if (maptype === 'roadmap') {
            map.setMapTypeId(kakao.maps.MapTypeId.ROADMAP);
        } else {
            map.setMapTypeId(kakao.maps.MapTypeId.HYBRID);
        }
    };

    // 지도를 확대하는 함수
    const zoomIn = () => {
        map.setLevel(map.getLevel() - 1);
    };

    // 지도를 축소하는 함수
    const zoomOut = () => {
        map.setLevel(map.getLevel() + 1);
    };

    // 장소 목록을 클릭했을 때 해당 장소로 이동하는 함수
    const handlePlaceClick = (place) => {
        const placePosition = new kakao.maps.LatLng(place.y, place.x);
        map.setCenter(placePosition);
        map.setLevel(1); // 지도의 확대 레벨을 1로 설정
    };

    // 지도 생성 함수
    const initMap = () => {
        const mapContainer = document.getElementById('map');
        const mapOption = {
            center: new kakao.maps.LatLng(36.5, 127.5), // 남한 중심 좌표
            level: 12, // 지도의 확대 레벨 (1: 가장 확대, 14: 가장 축소)
            maxLevel: 12
        };
        const map = new kakao.maps.Map(mapContainer, mapOption);

        setMap(map); // map 상태 업데이트
    };


    // 컴포넌트가 처음 렌더링될 때 지도 생성
    useEffect(() => {
        // Load Kakao Maps API script dynamically
        const script = document.createElement('script');
        script.src = 'https://dapi.kakao.com/v2/maps/sdk.js?appkey=01883844c2b9377c47a9c9d379f2863c&libraries=services&autoload=false';
        script.onload = () => {
            kakao.maps.load(() => {
                setKakaoLoaded(true);
                initMap();
            });
        };
        if (map && map.getLevel() > 12) {
            map.setLevel(12);
        }
        document.head.appendChild(script);

        // Clean up function
        return () => {
            // Remove the dynamically added script when the component unmounts
            document.head.removeChild(script);
        };
    }, []); // Empty dependency array to ensure it runs only once

    return (
        <div style={{ position: 'relative', width: '100%', height: '100vh' }}>
            {/* 검색어 입력란 및 결과 목록 */}
            <div className="search-box" style={{ position: 'absolute', top: '10px', left: '10px', zIndex: 10, backgroundColor: 'white', padding: '10px', borderRadius: '5px', boxShadow: '0 2px 4px rgba(0,0,0,0.2)', width: '400px' }}>
                <form onSubmit={searchPlaces} >
                    <input
                        type="text"
                        value={keyword}
                        onChange={handleChange}
                        placeholder="장소를 검색하세요."
                        id="keyword"
                        size="15"
                        style={{ width: '300px', height: '20px', marginRight: '10px' }}
                    />
                    <button type="submit" style={{ width: '80px', height: '25px' }}>검색하기</button>
                </form>
                {places.length > 0 && (
                    <div id="menu_wrap" className="bg_white" style={{ marginTop: '30px', maxHeight: '700px', overflowY: 'auto', backgroundColor: 'white' }}>
                        <ul id="placesList">
                            {places.map((place, index) => (
                                <li key={index} className="item" onClick={() => handlePlaceClick(place)}>
                                    <span className={`markerbg marker_${index + 1}`}></span>
                                    <div className="info">
                                        <h5>{place.place_name}</h5>
                                        <span>{place.road_address_name}</span>
                                        <span className="jibun gray">{place.address_name}</span>
                                        <span className="tel">{place.phone}</span>
                                    </div>
                                </li>
                            ))}
                        </ul>
                        <div id="pagination"></div>
                    </div>
                )}
            </div>

            {/* 지도를 표시할 div */}
            <div className='kakaoMap' id="map">
                <div className="mapStyle">
                    <button id="mapBtn" onClick={() => setMapType('roadmap')}>지도</button>
                    <button id="skyBtn" onClick={() => setMapType('skyview')}>스카이뷰</button>
                    <button id="ZoomInBtn" onClick={zoomIn}><img src="https://t1.daumcdn.net/localimg/localimages/07/mapapidoc/ico_plus.png" alt="확대"></img></button>
                    <br></br>
                    <button id="ZoomOutBtn" onClick={zoomOut}><img src="https://t1.daumcdn.net/localimg/localimages/07/mapapidoc/ico_minus.png" alt="축소"></img></button>
                </div>
            </div>
        </div >
    );
};

export default KakaoMap;
